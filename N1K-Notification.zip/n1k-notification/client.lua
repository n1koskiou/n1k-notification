--====================================================================--
--  N1K Notification - CLIENT SIDE
--====================================================================--

RegisterNetEvent("n1k-notification:client:show", function(data)
    SendNUIMessage({
        action = "show",
        type = data.type,
        title = data.title,
        text = data.text,
        duration = data.duration
    })
end)

--==================================================
-- Export (client-side usage)
--==================================================
exports("Notify", function(nType, title, text, duration)
    SendNUIMessage({
        action = "show",
        type = nType,
        title = title,
        text = text,
        duration = duration or Config.DefaultDuration
    })
end)
RegisterCommand("not-info", function(source, args, rawCommand)
    TriggerEvent("n1k-notification:client:show", {
        type = "info",
        title = "N1K-NOTIFICATION ",
        text = "Hello World | Info Notification Test",
        duration = 5000
    })
    
end, false)
RegisterCommand("not-success", function(source, args, rawCommand)
    TriggerEvent("n1k-notification:client:show", {
        type = "success",
        title = "N1K-NOTIFICATION ",
        text = "Hello World | Success Notification Test",
        duration = 5000
    })
    
end, false)
RegisterCommand("not-error", function(source, args, rawCommand)
    TriggerEvent("n1k-notification:client:show", {
        type = "error",
        title = "N1K-NOTIFICATION ",
        text = "Hello World | Error Notification Test",
        duration = 5000
    })
    
end, false)
RegisterCommand("not-combo", function(source, args, rawCommand)
    TriggerEvent("n1k-notification:client:show", {
        type = "info",
        title = "N1K-NOTIFICATION ",
        text = "Hello World | Info Notification Test",
        duration = 5000
    })
        TriggerEvent("n1k-notification:client:show", {
        type = "success",
        title = "N1K-NOTIFICATION ",
        text = "Hello World | Success Notification Test",
        duration = 5000
    })
        TriggerEvent("n1k-notification:client:show", {
        type = "error",
        title = "N1K-NOTIFICATION ",
        text = "Hello World | Error Notification Test",
        duration = 5000
    })
end, false)

