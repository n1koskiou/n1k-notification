--====================================================================--
--  N1K NOTIFICATION CONFIGURATION
--====================================================================--

Config = {}

--==================================================
-- CORE SETTINGS
--==================================================
-- Supported: "QBCORE", "ESX", "QBOX", "STANDALONE"
Config.Core = "QBCORE"

Config.CoreName = {
    QBCORE = "qb-core",
    ESX = "es_extended",
    QBOX = "qbx-core"
}

--==================================================
-- LOG SETTINGS
--==================================================
Config.Logs = {
    Enabled = true,
    Prefix = "[n1k-notification]"
}

--==================================================
-- DEBUG MODE
--==================================================
Config.Debug = {
    Enabled = false,
    PrintToConsole = false
}

--==================================================
-- SOUND SETTINGS
--==================================================
Config.Sounds = {
    Enabled = true,
    Volume = 0.4,
    Files = {
        success = "sounds/success.mp3",
        error = "sounds/error.mp3",
        info = "sounds/info.mp3"
    }
}

--==================================================
-- DEFAULT DURATION
--==================================================
Config.DefaultDuration = 5000

--==================================================
-- FOOTER OPTIONS
--==================================================
Config.Footer = {
    ShowTimestamp = true
}


--==================================================
-- UTILITY LOG FUNCTION
--==================================================
function Config.Log(message)
    if Config.Logs.Enabled then
        print(("%s %s"):format(Config.Logs.Prefix, message))
    end
end
