fx_version 'cerulean'
game 'gta5'

author 'N1K-Notification'
description 'Advanced Notification System'
version '2.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/sounds/success.mp3',
    'html/sounds/error.mp3',
    'html/sounds/info.mp3'
}

client_script 'client.lua'
server_script 'server.lua'
