window.addEventListener('message', function(event) {
    if (event.data.action === 'show') {
        createSingularityNotification(event.data);
    }
});

function createSingularityNotification(data) {
    const container = document.getElementById('container');
    if (!container) return;

    const notifId = `notif-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const duration = data.duration || 8000;

    const notif = document.createElement('div');
    notif.id = notifId;
    notif.className = `notification-wrapper ${data.type || 'info'}`;
    notif.style.setProperty('--notification-duration', `${duration}ms`);

    notif.innerHTML = `
        <div class="notification-aurora"></div>
        <div class="notification">
            <div class="notification-shimmer"></div>
            <div class="notification-border-glow"></div>
            
            <div class="corner-bracket top-left"></div>
            <div class="corner-bracket top-right"></div>
            <div class="corner-bracket bottom-left"></div>
            <div class="corner-bracket bottom-right"></div>

            <div class="icon-capsule">
                <div class="icon">${icons[data.type] || icons.info}</div>
            </div>

            <div class="content">
                <h1 class="title">${data.title || 'SYSTEM ALERT'}</h1>
                <p class="text">${data.text || 'No message content.'}</p>
                <div class="notification-footer">${getFooterText()}</div>
            </div>

            <div class="progress-bar">
                <div class="progress-bar-fill"></div>
            </div>
        </div>
    `;

    container.appendChild(notif);

    // Play sound
    playSound(data.type);

    setTimeout(() => {
        const el = document.getElementById(notifId);
        if (el) {
            el.classList.add('closing');
            setTimeout(() => el.remove(), 1000);
        }
    }, duration);
}

// Footer timestamp 
function getFooterText() {
    const now = new Date();
    let hours = now.getHours();
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // convert hour '0' to '12'
    const date = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')}`;
    return `${hours}:${minutes} ${ampm}`;
}


// Play sounds
function playSound(type) {
    const audio = document.getElementById(`sound-${type}`) || document.getElementById('sound-info');
    if (audio) {
        audio.currentTime = 0;
        audio.volume = 0.4;
        audio.play().catch(() => {});
    }
}

// Icons mapping
const icons = {
    info: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`,
    success: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`,
    error: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`
};
