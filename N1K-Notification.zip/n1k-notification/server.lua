-- n1k-notification | Server Side
-- Framework agnostic (works with QB, ESX, Standalone)

local resourceName = GetCurrentResourceName()

-- [ SERVER TRIGGER FUNCTION ]
function NotifyPlayer(src, type, title, message, duration)
    if not src or not type then return end
    TriggerClientEvent('n1k-notification:client:show', src, {
        type = type or 'info',
        title = title or 'SYSTEM',
        text = message or 'No message provided.',
        duration = duration or 5000
    })
end

-- [ EXAMPLE COMMAND ]
RegisterCommand('testnotify', function(source)
    NotifyPlayer(source, 'success', 'Mission Complete', 'You received $5000 reward!', 7000)
end)

-- [ OPTIONAL EXPORT for other scripts ]
exports('Notify', function(src, type, title, message, duration)
    NotifyPlayer(src, type, title, message, duration)
end)

-- [ OPTIONAL: Example QB/ESX Hook ]
-- Example: when player connects
AddEventHandler('playerConnecting', function(name)
    local src = source
    NotifyPlayer(src, 'info', 'Welcome', ('Hello %s, enjoy your stay!'):format(name), 6000)
end)

print(('^2[%s]^0 Notification system loaded successfully.'):format(resourceName))
